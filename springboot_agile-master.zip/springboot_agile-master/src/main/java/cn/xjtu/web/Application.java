package cn.xjtu.soto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SotoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SotoApplication.class, args);
    }

}
